SSv1.0 - B

Se alimenta con CC 55V y tiene los conectores jst.